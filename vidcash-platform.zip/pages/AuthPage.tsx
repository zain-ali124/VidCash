
import React, { useState } from 'react';
import { Page, AuthStep, Package, PaymentMethod, UserRole } from '../types';
import { Button, Card, CardContent, CardDescription, CardHeader, CardTitle, Input, Label } from '../components/ui/shadcn';
import { PACKAGES } from '../constants';

interface AuthPageProps {
    navigate: (page: Page) => void;
    onLogin: (role: UserRole) => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ navigate, onLogin }) => {
    const [step, setStep] = useState<AuthStep>('login');
    const [selectedPackage, setSelectedPackage] = useState<Package | null>(null);
    const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('JazzCash');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [message, setMessage] = useState('');

    const handlePackageSelect = (pkg: Package) => {
        setSelectedPackage(pkg);
        setStep('payment');
    };

    const handlePaymentSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        setMessage('');

        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 2000));

        setMessage('Your payment has been submitted for verification. An admin will review it and activate your account within 24 hours. You will be notified via email.');
        setIsSubmitting(false);
    };

    const renderStep = () => {
        switch (step) {
            case 'login':
                return <LoginForm setStep={setStep} onLogin={onLogin} />;
            case 'signup':
                return <SignupForm setStep={setStep} />;
            case 'verify':
                return <VerificationForm setStep={setStep} />;
            case 'package':
                return <PackageSelectionForm onPackageSelect={handlePackageSelect} />;
            case 'payment':
                if (!selectedPackage) {
                    setStep('package');
                    return null;
                }
                return (
                    <PaymentForm
                        pkg={selectedPackage}
                        paymentMethod={paymentMethod}
                        setPaymentMethod={setPaymentMethod}
                        onSubmit={handlePaymentSubmit}
                        isSubmitting={isSubmitting}
                        message={message}
                    />
                );
            default:
                return <LoginForm setStep={setStep} onLogin={onLogin} />;
        }
    };

    return (
        <div className="flex min-h-screen items-center justify-center bg-gray-50 dark:bg-gray-900 p-4">
            <div className="w-full max-w-md">
                <div className="text-center mb-6 cursor-pointer" onClick={() => navigate('landing')}>
                    <span className="text-3xl font-bold text-gray-800 dark:text-white">VidCash</span>
                </div>
                {renderStep()}
            </div>
        </div>
    );
};

// --- Child Components for each step ---

const LoginForm: React.FC<{ setStep: (step: AuthStep) => void, onLogin: (role: UserRole) => void }> = ({ setStep, onLogin }) => (
    <Card>
        <CardHeader>
            <CardTitle>Welcome Back</CardTitle>
            <CardDescription>Login to your account</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" placeholder="m@example.com" />
            </div>
            <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input id="password" type="password" />
            </div>
            <Button className="w-full bg-cyan-500 hover:bg-cyan-600 text-white" onClick={() => onLogin('viewer')}>Login as Viewer</Button>
            <Button variant="secondary" className="w-full" onClick={() => onLogin('youtuber')}>Login as YouTuber</Button>
            <div className="text-center text-sm">
                Don't have an account? <span className="text-cyan-500 cursor-pointer" onClick={() => setStep('signup')}>Sign Up</span>
            </div>
        </CardContent>
    </Card>
);

const SignupForm: React.FC<{ setStep: (step: AuthStep) => void }> = ({ setStep }) => (
    <Card>
        <CardHeader>
            <CardTitle>Create an Account</CardTitle>
            <CardDescription>Enter your details to get started.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" placeholder="your.email@example.com" required/>
            </div>
            <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" type="tel" placeholder="03001234567" required/>
            </div>
             <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input id="password" type="password" required/>
            </div>
            <Button className="w-full bg-cyan-500 hover:bg-cyan-600 text-white" onClick={() => setStep('verify')}>Continue</Button>
             <div className="text-center text-sm">
                Already have an account? <span className="text-cyan-500 cursor-pointer" onClick={() => setStep('login')}>Login</span>
            </div>
        </CardContent>
    </Card>
);

const VerificationForm: React.FC<{ setStep: (step: AuthStep) => void }> = ({ setStep }) => (
    <Card>
        <CardHeader>
            <CardTitle>Two-Step Verification</CardTitle>
            <CardDescription>We've sent a code to your email. Please enter it below.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
             <div className="space-y-2">
                <Label htmlFor="code">Verification Code</Label>
                <Input id="code" type="text" placeholder="123456" />
            </div>
            <Button className="w-full bg-cyan-500 hover:bg-cyan-600 text-white" onClick={() => setStep('package')}>Verify</Button>
        </CardContent>
    </Card>
);

const PackageSelectionForm: React.FC<{ onPackageSelect: (pkg: Package) => void }> = ({ onPackageSelect }) => (
    <Card className="max-w-4xl w-full">
         <CardHeader>
            <CardTitle>Choose Your Package</CardTitle>
            <CardDescription>Select a package to start your earning journey.</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {PACKAGES.map(pkg => (
                <div key={pkg.name} className="border border-border dark:border-dark-border rounded-lg p-4 cursor-pointer hover:bg-accent dark:hover:bg-dark-accent" onClick={() => onPackageSelect(pkg)}>
                    <h3 className="font-bold text-lg text-cyan-500">{pkg.name}</h3>
                    <p className="font-bold text-2xl">{pkg.price} PKR</p>
                    <ul className="text-sm text-muted-foreground dark:text-dark-muted-foreground mt-2 space-y-1">
                        <li>{pkg.videosPerDay} videos/day</li>
                        <li>{pkg.referralBonus} PKR per referral</li>
                    </ul>
                </div>
            ))}
        </CardContent>
    </Card>
);

const PaymentForm: React.FC<{
    pkg: Package,
    paymentMethod: PaymentMethod,
    setPaymentMethod: (method: PaymentMethod) => void,
    onSubmit: (e: React.FormEvent) => void,
    isSubmitting: boolean,
    message: string,
}> = ({ pkg, paymentMethod, setPaymentMethod, onSubmit, isSubmitting, message }) => {
    const paymentDetails = {
        JazzCash: { number: '0300-1234567', name: 'VidCash Admin' },
        EasyPaisa: { number: '0300-1234567', name: 'VidCash Admin' },
        Bank: { number: '0123-4567890123', name: 'VidCash Inc.', bank: 'Meezan Bank' },
    };

    if (message) {
        return (
            <Card>
                <CardHeader>
                    <CardTitle>Submission Received!</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-green-600 dark:text-green-400">{message}</p>
                </CardContent>
            </Card>
        );
    }
    
    return (
        <Card>
            <CardHeader>
                <CardTitle>Final Step: Payment</CardTitle>
                <CardDescription>Send {pkg.price} PKR to one of the accounts below to activate your <span className="font-bold text-cyan-500">{pkg.name}</span> package.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="flex space-x-2 mb-4">
                    {(['JazzCash', 'EasyPaisa', 'Bank'] as PaymentMethod[]).map(method => (
                        <Button key={method} variant={paymentMethod === method ? 'default' : 'outline'} onClick={() => setPaymentMethod(method)}>
                            {method}
                        </Button>
                    ))}
                </div>
                <div className="bg-secondary dark:bg-dark-secondary p-4 rounded-md text-sm mb-6">
                    <p><span className="font-semibold">Account Title:</span> {paymentDetails[paymentMethod].name}</p>
                    <p><span className="font-semibold">Account Number:</span> {paymentDetails[paymentMethod].number}</p>
                    {paymentMethod === 'Bank' && <p><span className="font-semibold">Bank Name:</span> {paymentDetails[paymentMethod].bank}</p>}
                </div>
                <form onSubmit={onSubmit} className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="tid">Transaction ID (TID)</Label>
                        <Input id="tid" placeholder="Enter the transaction ID" required/>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="screenshot">Payment Screenshot</Label>
                        <Input id="screenshot" type="file" required />
                    </div>
                    <Button type="submit" className="w-full bg-cyan-500 hover:bg-cyan-600 text-white" disabled={isSubmitting}>
                        {isSubmitting ? 'Submitting...' : 'Submit for Verification'}
                    </Button>
                </form>
            </CardContent>
        </Card>
    );
};

export default AuthPage;


import React, { useState } from 'react';
import { Page, User } from '../types';
import { Button, Card, CardContent, CardDescription, CardHeader, CardTitle, Input, Label } from '../components/ui/shadcn';
import { useTheme } from '../contexts/ThemeContext';

interface DashboardPageProps {
    user: User | null;
    onLogout: () => void;
    navigate: (page: Page) => void;
}

type DashboardView = 'overview' | 'tasks' | 'referrals' | 'withdraw' | 'history';

const SunIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2v2" /><path d="M12 20v2" /><path d="m4.93 4.93 1.41 1.41" /><path d="m17.66 17.66 1.41 1.41" /><path d="M2 12h2" /><path d="M20 12h2" /><path d="m6.34 17.66-1.41 1.41" /><path d="m19.07 4.93-1.41 1.41" />
  </svg>
);

const MoonIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" />
  </svg>
);

const ThemeToggle: React.FC = () => {
    const { theme, toggleTheme } = useTheme();
    return (
        <Button onClick={toggleTheme} variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
            {theme === 'light' ? <MoonIcon className="h-5 w-5" /> : <SunIcon className="h-5 w-5" />}
        </Button>
    );
};

const Sidebar: React.FC<{ view: DashboardView, setView: (view: DashboardView) => void, onLogout: () => void, navigate: (page: Page) => void }> = ({ view, setView, onLogout, navigate }) => {
    const navItems = [
        { id: 'overview', label: 'Overview' },
        { id: 'tasks', label: 'Daily Tasks' },
        { id: 'referrals', label: 'Referrals' },
        { id: 'withdraw', label: 'Withdraw' },
        { id: 'history', label: 'Payment History' },
    ];
    return (
        <div className="w-64 bg-secondary dark:bg-dark-secondary/50 border-r border-border dark:border-dark-border p-4 flex flex-col">
            <div className="flex items-center space-x-2 mb-8 cursor-pointer" onClick={() => navigate('landing')}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-cyan-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 8-4 4 4 4" /><path d="M20 12H8" /></svg>
                <span className="text-2xl font-bold">VidCash</span>
            </div>
            <nav className="flex-grow">
                {navItems.map(item => (
                    <button
                        key={item.id}
                        onClick={() => setView(item.id as DashboardView)}
                        className={`w-full text-left px-4 py-2 rounded-lg transition-colors text-sm font-medium ${
                            view === item.id ? 'bg-cyan-500 text-white' : 'hover:bg-accent dark:hover:bg-dark-accent'
                        }`}
                    >
                        {item.label}
                    </button>
                ))}
            </nav>
            <div className="mt-auto">
                <ThemeToggle />
                <Button variant="ghost" className="w-full justify-start mt-2" onClick={onLogout}>Logout</Button>
            </div>
        </div>
    );
};

const DashboardPage: React.FC<DashboardPageProps> = ({ user, onLogout, navigate }) => {
    const [view, setView] = useState<DashboardView>('overview');
    if (!user) {
        // This should not happen if routing is correct, but as a fallback
        return <div>Loading...</div>;
    }

    const renderView = () => {
        switch(view) {
            case 'overview': return <Overview user={user} />;
            case 'tasks': return <DailyTasks />;
            case 'referrals': return <Referrals />;
            case 'withdraw': return <Withdraw user={user}/>;
            case 'history': return <PaymentHistory />;
            default: return <Overview user={user} />;
        }
    }

    return (
        <div className="flex min-h-screen">
            <Sidebar view={view} setView={setView} onLogout={onLogout} navigate={navigate}/>
            <main className="flex-1 p-8 bg-gray-50 dark:bg-gray-900/50">
                <h1 className="text-3xl font-bold mb-2">Hello, {user.name}!</h1>
                <p className="text-muted-foreground dark:text-dark-muted-foreground mb-8">Welcome to your dashboard.</p>
                {renderView()}
            </main>
        </div>
    );
};

const Overview: React.FC<{ user: User }> = ({ user }) => (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
            <CardHeader><CardTitle>Account Summary</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
                <div><Label>Package</Label><p className="font-bold text-lg text-cyan-500">{user.package}</p></div>
                <div><Label>Referrals</Label><p className="font-bold text-lg">{user.referrals}</p></div>
                <div><Label>Current Balance</Label><p className="font-bold text-lg">{user.balance} PKR</p></div>
                <div><Label>Withdrawal Status</Label><p className="font-bold text-lg">{user.withdrawalStatus}</p></div>
            </CardContent>
        </Card>
        <Card>
            <CardHeader><CardTitle>Today's Progress</CardTitle></CardHeader>
            <CardContent>
                <Label>Videos Watched: 3 / 20</Label>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mt-2">
                    <div className="bg-cyan-500 h-2.5 rounded-full" style={{width: '15%'}}></div>
                </div>
            </CardContent>
        </Card>
    </div>
);

const DailyTasks: React.FC = () => {
    const videos = Array.from({ length: 20 }, (_, i) => ({ id: i + 1, title: `Promotional Video ${i + 1}`, watched: i < 3 }));
    return (
        <Card>
            <CardHeader>
                <CardTitle>Daily Tasks</CardTitle>
                <CardDescription>Watch videos to earn. You have 17 videos left for today.</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {videos.map(video => (
                    <div key={video.id} className="border dark:border-dark-border rounded-lg p-4 flex items-center justify-between">
                        <div>
                            <p className="font-semibold">{video.title}</p>
                            <p className={`text-sm ${video.watched ? 'text-green-500' : 'text-muted-foreground dark:text-dark-muted-foreground'}`}>{video.watched ? 'Watched' : 'Pending'}</p>
                        </div>
                        <Button size="sm" disabled={video.watched}>{video.watched ? 'Done' : 'Watch'}</Button>
                    </div>
                ))}
            </CardContent>
        </Card>
    );
};

const Referrals: React.FC = () => (
    <Card>
        <CardHeader><CardTitle>Referral System</CardTitle></CardHeader>
        <CardContent>
            <Label>Your Referral Link</Label>
            <div className="flex items-center space-x-2 mt-2">
                <Input readOnly value="https://vidcash.com/ref/alex123" />
                <Button>Copy</Button>
            </div>
            <div className="grid grid-cols-3 gap-4 mt-6 text-center">
                <div><Label>Total Referrals</Label><p className="text-2xl font-bold">23</p></div>
                <div><Label>Active Referrals</Label><p className="text-2xl font-bold">18</p></div>
                <div><Label>Commission Earned</Label><p className="text-2xl font-bold">3,450 PKR</p></div>
            </div>
            <h4 className="font-semibold mt-8 mb-4">Your Team</h4>
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                    <thead className="bg-secondary dark:bg-dark-secondary">
                        <tr><th className="p-2">User</th><th className="p-2">Join Date</th><th className="p-2">Status</th></tr>
                    </thead>
                    <tbody>
                        <tr className="border-b dark:border-dark-border">
                            <td className="p-2">user1@example.com</td><td className="p-2">2023-10-15</td><td className="p-2 text-green-500">Active</td>
                        </tr>
                        <tr className="border-b dark:border-dark-border">
                            <td className="p-2">user2@example.com</td><td className="p-2">2023-10-12</td><td className="p-2 text-green-500">Active</td>
                        </tr>
                        <tr className="border-b dark:border-dark-border">
                            <td className="p-2">user3@example.com</td><td className="p-2">2023-10-11</td><td className="p-2 text-red-500">Inactive</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </CardContent>
    </Card>
);

const Withdraw: React.FC<{ user: User }> = ({ user }) => (
    <Card>
        <CardHeader>
            <CardTitle>Withdraw Earnings</CardTitle>
            <CardDescription>Your current balance is {user.balance} PKR.</CardDescription>
        </CardHeader>
        <CardContent className="max-w-md">
            <div className="space-y-4">
                <div className="space-y-2">
                    <Label>Amount</Label>
                    <Input placeholder="Enter amount to withdraw" />
                </div>
                <div className="space-y-2">
                    <Label>Method</Label>
                    <select className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm dark:border-dark-input dark:bg-dark-background">
                        <option>JazzCash</option>
                        <option>EasyPaisa</option>
                        <option>Bank Transfer</option>
                    </select>
                </div>
                <div className="space-y-2">
                    <Label>Account Number</Label>
                    <Input placeholder="Your account number" />
                </div>
                <Button className="w-full bg-cyan-500 text-white" disabled={user.withdrawalStatus !== 'Eligible'}>Request Withdrawal</Button>
                {user.withdrawalStatus !== 'Eligible' && <p className="text-sm text-red-500 text-center">{user.withdrawalStatus}</p>}
            </div>
        </CardContent>
    </Card>
);

const PaymentHistory: React.FC = () => (
    <Card>
        <CardHeader><CardTitle>Payment History</CardTitle></CardHeader>
        <CardContent>
            <table className="w-full text-sm text-left">
                <thead className="bg-secondary dark:bg-dark-secondary">
                    <tr><th className="p-2">Date</th><th className="p-2">Type</th><th className="p-2">Amount</th><th className="p-2">Status</th></tr>
                </thead>
                <tbody>
                    <tr className="border-b dark:border-dark-border"><td className="p-2">2023-10-20</td><td className="p-2">Withdrawal</td><td className="p-2">5000 PKR</td><td className="p-2 text-yellow-500">Pending</td></tr>
                    <tr className="border-b dark:border-dark-border"><td className="p-2">2023-09-28</td><td className="p-2">Withdrawal</td><td className="p-2">7500 PKR</td><td className="p-2 text-green-500">Approved</td></tr>
                    <tr className="border-b dark:border-dark-border"><td className="p-2">2023-09-01</td><td className="p-2">Deposit</td><td className="p-2">5000 PKR</td><td className="p-2 text-green-500">Approved</td></tr>
                </tbody>
            </table>
        </CardContent>
    </Card>
);

export default DashboardPage;

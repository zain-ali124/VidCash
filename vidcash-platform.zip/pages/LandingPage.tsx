
import React from 'react';
import { Page, Package } from '../types';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
// FIX: Import CardFooter component
import { Button, Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle, Input, Label } from '../components/ui/shadcn';
import { PACKAGES, TESTIMONIALS } from '../constants';

interface LandingPageProps {
    navigate: (page: Page) => void;
}

const HeroSection: React.FC<{ navigate: (page: Page) => void }> = ({ navigate }) => (
    <section className="py-20 md:py-32">
        <div className="container mx-auto max-w-7xl text-center px-4">
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tighter text-gray-900 dark:text-white">
                Get Paid to Watch Videos. <br />
                <span className="text-cyan-500">Boost Your YouTube Channel.</span>
            </h1>
            <p className="mt-6 max-w-2xl mx-auto text-lg text-muted-foreground dark:text-dark-muted-foreground">
                The ultimate platform connecting viewers who want to earn with creators who need engagement. Simple tasks, real rewards, and authentic growth.
            </p>
            <div className="mt-10 flex justify-center gap-4">
                <Button size="lg" onClick={() => navigate('auth')} className="bg-cyan-500 hover:bg-cyan-600 text-white shadow-lg shadow-cyan-500/20">
                    Start Earning Now
                </Button>
                <Button size="lg" variant="outline" onClick={() => navigate('auth')}>
                    Promote My Video
                </Button>
            </div>
        </div>
    </section>
);


const FeaturesSection: React.FC = () => {
    const features = [
        { title: 'Daily Tasks', description: 'Watch a set number of videos each day based on your package and earn instantly.' },
        { title: 'Powerful Referrals', description: 'Invite friends and build your team to earn direct bonuses and lifetime commissions.' },
        { title: 'Secure Withdrawals', description: 'Easily withdraw your earnings through JazzCash, EasyPaisa, or Bank Transfer.' },
        { title: 'Real Engagement', description: 'For YouTubers, get real views from an active user base to boost your channel rankings.' },
    ];
    return (
        <section id="features" className="py-20 bg-secondary dark:bg-dark-secondary">
            <div className="container mx-auto max-w-7xl px-4">
                <div className="text-center">
                    <h2 className="text-3xl font-bold tracking-tight">How It Works</h2>
                    <p className="mt-2 text-muted-foreground dark:text-dark-muted-foreground">Simple, transparent, and effective for everyone.</p>
                </div>
                <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    {features.map((feature, index) => (
                        <Card key={index}>
                            <CardHeader>
                                <CardTitle>{feature.title}</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-muted-foreground dark:text-dark-muted-foreground">{feature.description}</p>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </div>
        </section>
    );
};

const PackageCard: React.FC<{ pkg: Package, navigate: (page: Page) => void }> = ({ pkg, navigate }) => (
    <Card className={cn('flex flex-col', pkg.popular ? `${pkg.color} border-2 relative` : `border-border dark:border-dark-border`)}>
        {pkg.popular && (
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-cyan-500 text-white px-3 py-1 text-sm font-semibold rounded-full">
                Most Popular
            </div>
        )}
        <CardHeader className="items-center">
            <CardTitle className="text-cyan-500">{pkg.name}</CardTitle>
            <p className="text-4xl font-bold">
                {pkg.price} <span className="text-lg font-medium text-muted-foreground dark:text-dark-muted-foreground">PKR</span>
            </p>
        </CardHeader>
        <CardContent className="flex-grow">
            <ul className="space-y-3 text-sm text-muted-foreground dark:text-dark-muted-foreground">
                <li className="flex items-center"><span className="font-semibold text-foreground dark:text-dark-foreground mr-2">{pkg.videosPerDay}</span> Videos/Day</li>
                <li className="flex items-center"><span className="font-semibold text-foreground dark:text-dark-foreground mr-2">{pkg.referralBonus} PKR</span> per Referral</li>
                <li className="flex items-center"><span className="font-semibold text-foreground dark:text-dark-foreground mr-2">{pkg.referralWithdrawalBonus}%</span> from Referral Withdrawals</li>
            </ul>
        </CardContent>
        <CardFooter>
            <Button onClick={() => navigate('auth')} className="w-full bg-cyan-500 hover:bg-cyan-600 text-white">
                Choose Plan
            </Button>
        </CardFooter>
    </Card>
);

const PackagesSection: React.FC<{ navigate: (page: Page) => void }> = ({ navigate }) => (
    <section className="py-20">
        <div className="container mx-auto max-w-7xl px-4">
            <div className="text-center">
                <h2 className="text-3xl font-bold tracking-tight">Our Packages</h2>
                <p className="mt-2 text-muted-foreground dark:text-dark-muted-foreground">Choose the plan that's right for you and start earning.</p>
            </div>
            <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {PACKAGES.map((pkg) => (
                    <PackageCard key={pkg.name} pkg={pkg} navigate={navigate} />
                ))}
            </div>
        </div>
    </section>
);

const TestimonialsSection: React.FC = () => (
    <section className="py-20 bg-secondary dark:bg-dark-secondary">
        <div className="container mx-auto max-w-7xl px-4">
            <div className="text-center">
                <h2 className="text-3xl font-bold tracking-tight">What Our Users Say</h2>
                <p className="mt-2 text-muted-foreground dark:text-dark-muted-foreground">Real stories from our community members.</p>
            </div>
            <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {TESTIMONIALS.map((testimonial, index) => (
                    <Card key={index} className="flex flex-col">
                        <CardContent className="pt-6 flex-grow">
                            <p className="text-muted-foreground dark:text-dark-muted-foreground">"{testimonial.text}"</p>
                        </CardContent>
                        <CardFooter className="mt-4">
                            <img src={testimonial.avatar} alt={testimonial.name} className="h-12 w-12 rounded-full mr-4" />
                            <div>
                                <p className="font-semibold">{testimonial.name}</p>
                                <p className="text-sm text-muted-foreground dark:text-dark-muted-foreground">{testimonial.role}</p>
                            </div>
                        </CardFooter>
                    </Card>
                ))}
            </div>
        </div>
    </section>
);

const ContactSection: React.FC = () => (
    <section className="py-20">
        <div className="container mx-auto max-w-3xl px-4">
            <div className="text-center">
                <h2 className="text-3xl font-bold tracking-tight">Get in Touch</h2>
                <p className="mt-2 text-muted-foreground dark:text-dark-muted-foreground">Have questions? We'd love to hear from you.</p>
            </div>
            <Card className="mt-12">
                <CardContent className="p-6">
                    <form className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="name">Name</Label>
                                <Input id="name" placeholder="Your Name" />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="email">Email</Label>
                                <Input id="email" type="email" placeholder="Your Email" />
                            </div>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="message">Message</Label>
                            <textarea id="message" placeholder="Your message..." className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm dark:border-dark-input dark:bg-dark-background"></textarea>
                        </div>
                        <Button type="submit" className="w-full bg-cyan-500 hover:bg-cyan-600 text-white">Send Message</Button>
                    </form>
                </CardContent>
            </Card>
        </div>
    </section>
);


const LandingPage: React.FC<LandingPageProps> = ({ navigate }) => {
    return (
        <>
            <Header navigate={navigate} />
            <main>
                <HeroSection navigate={navigate} />
                <FeaturesSection />
                <PackagesSection navigate={navigate} />
                <TestimonialsSection />
                <ContactSection />
            </main>
            <Footer navigate={navigate} />
        </>
    );
};

// Simple utility to merge tailwind classes, as it might be used in multiple components.
const cn = (...classes: (string | undefined | null | false)[]) => {
    return classes.filter(Boolean).join(' ');
}


export default LandingPage;

import React from 'react';
import { Page } from '../../types';
import { useTheme } from '../../contexts/ThemeContext';
import { Button } from '../ui/shadcn';

interface HeaderProps {
    navigate: (page: Page) => void;
}

const Logo: React.FC<{ navigate: (page: Page) => void }> = ({ navigate }) => (
    <div onClick={() => navigate('landing')} className="flex items-center space-x-2 cursor-pointer">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-cyan-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="m12 8-4 4 4 4" />
            <path d="M20 12H8" />
        </svg>
        <span className="text-2xl font-bold text-gray-800 dark:text-white">VidCash</span>
    </div>
);

const SunIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2v2" /><path d="M12 20v2" /><path d="m4.93 4.93 1.41 1.41" /><path d="m17.66 17.66 1.41 1.41" /><path d="M2 12h2" /><path d="M20 12h2" /><path d="m6.34 17.66-1.41 1.41" /><path d="m19.07 4.93-1.41 1.41" />
  </svg>
);

const MoonIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" />
  </svg>
);


const ThemeToggle: React.FC = () => {
    const { theme, toggleTheme } = useTheme();
    return (
        <Button onClick={toggleTheme} variant="ghost" size="icon">
            {theme === 'light' ? <MoonIcon className="h-5 w-5" /> : <SunIcon className="h-5 w-5" />}
        </Button>
    );
};

const Header: React.FC<HeaderProps> = ({ navigate }) => {
    const navLinks = [
        { name: 'Features', page: 'landing', section: '#features' },
        { name: 'Rules', page: 'rules' },
        { name: 'FAQ', page: 'faq' },
    ];

    const handleNavClick = (page: Page, section?: string) => {
        navigate(page);
        if (page === 'landing' && section) {
            setTimeout(() => {
                document.querySelector(section)?.scrollIntoView({ behavior: 'smooth' });
            }, 100);
        }
    };
    
    return (
        <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 dark:border-dark-border/40 dark:bg-dark-background/95 dark:supports-[backdrop-filter]:bg-dark-background/60">
            <div className="container mx-auto flex h-16 max-w-7xl items-center justify-between px-4">
                <Logo navigate={navigate} />
                <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
                    {navLinks.map(link => (
                        <span key={link.name} onClick={() => handleNavClick(link.page as Page, link.section)} className="cursor-pointer text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors">
                            {link.name}
                        </span>
                    ))}
                </nav>
                <div className="flex items-center space-x-4">
                    <ThemeToggle />
                    <Button variant="outline" onClick={() => navigate('auth')}>Login</Button>
                    <Button onClick={() => navigate('auth')} className="bg-cyan-500 hover:bg-cyan-600 text-white">Sign Up</Button>
                </div>
            </div>
        </header>
    );
};

export default Header;

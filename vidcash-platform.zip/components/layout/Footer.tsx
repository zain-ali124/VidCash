
import React from 'react';
import { Page } from '../../types';

interface FooterProps {
    navigate: (page: Page) => void;
}

const Footer: React.FC<FooterProps> = ({ navigate }) => {
    const footerLinks = [
        { name: 'Rules', page: 'rules' },
        { name: 'FAQ', page: 'faq' },
        { name: 'Terms & Conditions', page: 'terms' },
        { name: 'Privacy Policy', page: 'privacy' },
    ];
    return (
        <footer className="border-t border-border dark:border-dark-border bg-gray-50 dark:bg-gray-900">
            <div className="container mx-auto max-w-7xl px-4 py-12">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                    <div className="md:col-span-1">
                        <div className="flex items-center space-x-2">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-cyan-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="m12 8-4 4 4 4" />
                                <path d="M20 12H8" />
                            </svg>
                            <span className="text-2xl font-bold text-gray-800 dark:text-white">VidCash</span>
                        </div>
                        <p className="mt-4 text-sm text-muted-foreground dark:text-dark-muted-foreground">
                            Earn money by watching videos. Promote your content to a real audience.
                        </p>
                    </div>
                    <div className="md:col-span-3 grid grid-cols-2 md:grid-cols-3 gap-8">
                        <div>
                            <h4 className="font-semibold text-foreground dark:text-dark-foreground">Platform</h4>
                            <ul className="mt-4 space-y-2">
                                {footerLinks.slice(0, 2).map(link => (
                                    <li key={link.name}>
                                        <span onClick={() => navigate(link.page as Page)} className="text-sm text-muted-foreground dark:text-dark-muted-foreground hover:text-cyan-500 cursor-pointer">{link.name}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <div>
                             <h4 className="font-semibold text-foreground dark:text-dark-foreground">Legal</h4>
                            <ul className="mt-4 space-y-2">
                                {footerLinks.slice(2, 4).map(link => (
                                    <li key={link.name}>
                                        <span onClick={() => navigate(link.page as Page)} className="text-sm text-muted-foreground dark:text-dark-muted-foreground hover:text-cyan-500 cursor-pointer">{link.name}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <div>
                            <h4 className="font-semibold text-foreground dark:text-dark-foreground">Contact Us</h4>
                            <p className="mt-4 text-sm text-muted-foreground dark:text-dark-muted-foreground">contact@vidcash.com</p>
                        </div>
                    </div>
                </div>
                <div className="mt-12 border-t border-border dark:border-dark-border pt-8 text-center text-sm text-muted-foreground dark:text-dark-muted-foreground">
                    <p>&copy; {new Date().getFullYear()} VidCash. All rights reserved.</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
